from setuptools import setup
setup(
    name="pmod",
    version="1.0",
    description="Example distributed package",
    author="Guillermo Leon",
    author_email="gleon@savingl.cl",
    url="https://savingl.cl",
    packages=["Modules"])