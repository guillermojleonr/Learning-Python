#This is a module: .py, .pyc file


""" import functions
functions.sumar(1,2) """ #in order to use the function you have to place the module name first

""" from functions import sumar #imports only sumar function
sumar(1,2) """

from functions import * #imports everything from the module
sumar(1,2)

