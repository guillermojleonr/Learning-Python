def sumar(op1,op2):
    return print(op1+op2)

sumar(1,2)